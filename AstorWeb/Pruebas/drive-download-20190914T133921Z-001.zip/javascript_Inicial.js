
function Player(nombre,apellido,apodo,dorsal) {
    this.Nombre = nombre
    this.Apellido = apellido
    this.Apodo = apodo
    this.Dorsal = dorsal

}

let mJugador = new Player('Matias','De Olivera','Tuty',5)


document.write(mJugador);